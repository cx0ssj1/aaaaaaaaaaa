﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace ProyectoTprog
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            // Asigna el evento KeyPress a cada TextBox para validar que solo se ingresen números.
            // Esto asegura que los campos solo acepten dígitos y un solo punto decimal.
            txbGas.KeyPress += ValidarEntradaNumerica;
            txbAgua.KeyPress += ValidarEntradaNumerica;
            txbInternet.KeyPress += ValidarEntradaNumerica;
            txbLuz.KeyPress += ValidarEntradaNumerica;

            // Cargar datos desde el archivo al iniciar la aplicación.
            // Esto permite que cualquier dato previamente guardado en el archivo sea cargado en la grilla.
            CargarDesdeArchivo();
        }

        // Método que se encarga de validar la entrada del usuario en los TextBoxes.
        // Solo permite la entrada de números y un único punto decimal.
        private void ValidarEntradaNumerica(object sender, KeyPressEventArgs e)
        {
            // Si el carácter ingresado no es un número, un punto o una tecla de control, lo rechaza.
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && e.KeyChar != '.')
            {
                MessageBox.Show("Los datos están en formato incorrecto. Ingrese solo números y puntos.", "ERROR EN FORMATO");
                e.Handled = true;  // Evita que el carácter no válido se muestre en el TextBox.
            }

            // Asegura que solo se permita un único punto decimal.
            TextBox textBox = sender as TextBox;
            if (e.KeyChar == '.' && textBox.Text.Contains("."))
            {
                e.Handled = true;
            }
        }

        // Método para agregar un nuevo registro de gastos a la grilla y guardarlo en un archivo.
        // Verifica que el mes y año no hayan sido previamente registrados para evitar duplicados.
        private void btnIngresar_Click(object sender, EventArgs e)
        {
            string mesAño = MesAñodeing.Value.ToString("MM/yyyy");  // Obtiene el mes y año seleccionado en el formato MM/yyyy.

            // Verifica que el mes y año no estén duplicados en la grilla.
            foreach (DataGridViewRow row in grillaGastos.Rows)
            {
                if (row.Cells[0].Value != null && row.Cells[0].Value.ToString() == mesAño)
                {
                    MessageBox.Show("El mes y año ya están ingresados.", "Error en mes o año", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;  // Detiene el proceso si el mes y año ya están registrados.
                }
            }

            // Crea un nuevo objeto GastoMensual con los datos ingresados.
            GastoMensual gasto = new GastoMensual
            {
                MesAño = mesAño,
                Gas = Convert.ToDouble(txbGas.Text),
                Agua = Convert.ToDouble(txbAgua.Text),
                Internet = Convert.ToDouble(txbInternet.Text),
                Luz = Convert.ToDouble(txbLuz.Text)
            };

            // Calcula el total mensual sumando los diferentes gastos y lo agrega a la grilla.
            double totalMensual = gasto.CalcularGastoTotal();
            grillaGastos.Rows.Add(gasto.MesAño, gasto.Gas, gasto.Agua, gasto.Internet, gasto.Luz, totalMensual);

            // Guarda el contenido de la grilla en un archivo después de agregar el nuevo registro.
            GuardarEnArchivo();

            // Llama a RevisarMesesCompleto para verificar si ya se han registrado los 12 meses.
            RevisarMesesCompleto();
        }

        // Método que guarda el contenido actual de la grilla en un archivo CSV.
        // Guarda cada valor separado por comas, lo cual facilita su lectura en programas como Excel.
        private void GuardarEnArchivo()
        {
            using (StreamWriter writer = new StreamWriter("gastos.txt"))
            {
                // Escribe los encabezados de las columnas en el archivo.
                writer.WriteLine("Mes/Año,Gas,Agua,Internet,Luz,Gasto Total");

                // Recorre cada fila en la grilla y guarda sus datos en el archivo.
                foreach (DataGridViewRow row in grillaGastos.Rows)
                {
                    if (row.Cells[0].Value != null)  // Verifica que la fila no esté vacía.
                    {
                        writer.WriteLine(
                            $"{row.Cells[0].Value}," +
                            $"{row.Cells[1].Value}," +
                            $"{row.Cells[2].Value}," +
                            $"{row.Cells[3].Value}," +
                            $"{row.Cells[4].Value}," +
                            $"{row.Cells[5].Value}"
                        );
                    }
                }
            }
        }

        // Método que permite editar un registro seleccionado en la grilla y guardar los cambios.
        private void btnEditar_Click(object sender, EventArgs e)
        {
            int rowIndex = grillaGastos.CurrentCell.RowIndex;  // Obtiene el índice de la fila seleccionada.

            // Actualiza los valores de la fila seleccionada con los datos ingresados en los TextBoxes.
            grillaGastos[1, rowIndex].Value = Convert.ToDouble(txbGas.Text);
            grillaGastos[2, rowIndex].Value = Convert.ToDouble(txbAgua.Text);
            grillaGastos[3, rowIndex].Value = Convert.ToDouble(txbInternet.Text);
            grillaGastos[4, rowIndex].Value = Convert.ToDouble(txbLuz.Text);
            grillaGastos[5, rowIndex].Value = Convert.ToDouble(txbGas.Text) + Convert.ToDouble(txbAgua.Text) + Convert.ToDouble(txbInternet.Text) + Convert.ToDouble(txbLuz.Text);

            // Guarda los cambios en el archivo.
            GuardarEnArchivo();
            RevisarMesesCompleto();
        }

        // Método para eliminar una fila seleccionada en la grilla y guardar los cambios.
        private void btnEliminar_Click(object sender, EventArgs e)
        {
            // Elimina la fila seleccionada de la grilla.
            if (grillaGastos.SelectedRows.Count > 0)
            {
                grillaGastos.Rows.RemoveAt(grillaGastos.SelectedRows[0].Index);
            }
            GuardarEnArchivo();  // Guarda los cambios en el archivo.

            RevisarMesesCompleto();  // Verifica si se deben habilitar o deshabilitar botones después de eliminar.
        }

        // Método que calcula el gasto anual sumando todos los valores en la columna de Gasto Total.
        private void btnCalcAnual_Click(object sender, EventArgs e)
        {
            double gastoAnual = 0;

            // Recorre cada fila y suma el valor de la columna "Gasto Total".
            foreach (DataGridViewRow row in grillaGastos.Rows)
            {
                if (row.Cells[5].Value != null)
                {
                    gastoAnual += Convert.ToDouble(row.Cells[5].Value);
                }
            }

            // Muestra el gasto anual total en un label con formato de moneda.
            lblGastoAnual.Text = $"Gasto Anual Total: \n {gastoAnual:C}";
        }

        // Método que carga los datos desde un archivo CSV al iniciar la aplicación.
        // Esto permite que los datos previamente guardados se muestren en la grilla al iniciar la aplicación.
        private void CargarDesdeArchivo()
        {
            if (File.Exists("gastos.txt"))
            {
                using (StreamReader reader = new StreamReader("gastos.txt"))
                {
                    reader.ReadLine();  // Lee y descarta la primera línea que contiene los encabezados.

                    // Lee cada línea del archivo y la agrega a la grilla.
                    while (!reader.EndOfStream)
                    {
                        string line = reader.ReadLine();
                        string[] values = line.Split(',');

                        // Verifica que la línea contenga todos los valores esperados antes de agregarla a la grilla.
                        if (values.Length == 6)
                        {
                            grillaGastos.Rows.Add(values[0], Convert.ToDouble(values[1]), Convert.ToDouble(values[2]), Convert.ToDouble(values[3]), Convert.ToDouble(values[4]), Convert.ToDouble(values[5]));
                        }
                    }
                }
            }
        }

        // Método que verifica si se han registrado los 12 meses únicos en la grilla.
        // Si hay 12 meses únicos, habilita los botones para calcular el gasto anual y limpiar el registro.
        private void RevisarMesesCompleto()
        {
            int mesesUnicos = 0;

            // Recorre cada fila de la grilla y cuenta los meses únicos.
            for (int i = 0; i < grillaGastos.Rows.Count; i++)
            {
                string mesAñoActual = grillaGastos.Rows[i].Cells[0].Value?.ToString();

                if (string.IsNullOrEmpty(mesAñoActual))
                    continue;

                bool esMesDuplicado = false;
                // Recorre las filas anteriores para verificar si el mes ya fue contado.
                for (int j = 0; j < i; j++)
                {
                    string mesAñoPrevio = grillaGastos.Rows[j].Cells[0].Value?.ToString();
                    if (mesAñoActual == mesAñoPrevio)
                    {
                        esMesDuplicado = true;
                        break;
                    }
                }

                if (!esMesDuplicado)
                {
                    mesesUnicos++;  // Solo cuenta los meses únicos.
                }
            }

            // Habilita los botones solo si hay exactamente 12 meses únicos registrados.
            if (mesesUnicos == 12)
            {
                lblGastoAnual.Visible = true;
                btnCalcAnual.Visible = true;
                btnLimpiar.Visible = true;
            }
            else
            {
                btnCalcAnual.Visible = false;
                btnLimpiar.Visible = false;
            }
        }

        // Método que limpia el contenido del label que muestra el gasto anual.
        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            lblGastoAnual.Text = string.Empty;  // Borra el texto en el label de Gasto Anual.
        }
    }
}
