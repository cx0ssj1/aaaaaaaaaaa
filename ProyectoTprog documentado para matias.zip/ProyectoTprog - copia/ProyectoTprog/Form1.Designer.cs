﻿namespace ProyectoTprog
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.grillaGastos = new System.Windows.Forms.DataGridView();
            this.coMes = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.coGas = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.coAgua = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.coInternet = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.coLuz = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.coGastoTotal = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.MesAñodeing = new System.Windows.Forms.DateTimePicker();
            this.label5 = new System.Windows.Forms.Label();
            this.txbLuz = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txbInternet = new System.Windows.Forms.TextBox();
            this.btnEliminar = new System.Windows.Forms.Button();
            this.txbAgua = new System.Windows.Forms.TextBox();
            this.btnEditar = new System.Windows.Forms.Button();
            this.btnIngresar = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.txbGas = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnCalcAnual = new System.Windows.Forms.Button();
            this.lblGastoAnual = new System.Windows.Forms.Label();
            this.btnLimpiar = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.grillaGastos)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // grillaGastos
            // 
            this.grillaGastos.AllowUserToAddRows = false;
            this.grillaGastos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grillaGastos.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.coMes,
            this.coGas,
            this.coAgua,
            this.coInternet,
            this.coLuz,
            this.coGastoTotal});
            this.grillaGastos.GridColor = System.Drawing.SystemColors.ControlDarkDark;
            this.grillaGastos.Location = new System.Drawing.Point(29, 649);
            this.grillaGastos.Margin = new System.Windows.Forms.Padding(6);
            this.grillaGastos.Name = "grillaGastos";
            this.grillaGastos.ReadOnly = true;
            this.grillaGastos.RowHeadersWidth = 51;
            this.grillaGastos.Size = new System.Drawing.Size(961, 433);
            this.grillaGastos.TabIndex = 1001;
            // 
            // coMes
            // 
            this.coMes.HeaderText = "Mes/año";
            this.coMes.MinimumWidth = 10;
            this.coMes.Name = "coMes";
            this.coMes.ReadOnly = true;
            this.coMes.Width = 200;
            // 
            // coGas
            // 
            this.coGas.HeaderText = "Gas";
            this.coGas.MinimumWidth = 6;
            this.coGas.Name = "coGas";
            this.coGas.ReadOnly = true;
            this.coGas.Width = 125;
            // 
            // coAgua
            // 
            this.coAgua.HeaderText = "Agua";
            this.coAgua.MinimumWidth = 6;
            this.coAgua.Name = "coAgua";
            this.coAgua.ReadOnly = true;
            this.coAgua.Width = 125;
            // 
            // coInternet
            // 
            this.coInternet.HeaderText = "Internet";
            this.coInternet.MinimumWidth = 6;
            this.coInternet.Name = "coInternet";
            this.coInternet.ReadOnly = true;
            this.coInternet.Width = 125;
            // 
            // coLuz
            // 
            this.coLuz.HeaderText = "Luz";
            this.coLuz.MinimumWidth = 6;
            this.coLuz.Name = "coLuz";
            this.coLuz.ReadOnly = true;
            this.coLuz.Width = 125;
            // 
            // coGastoTotal
            // 
            this.coGastoTotal.HeaderText = "Gasto Total";
            this.coGastoTotal.MinimumWidth = 10;
            this.coGastoTotal.Name = "coGastoTotal";
            this.coGastoTotal.ReadOnly = true;
            this.coGastoTotal.Width = 200;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.MesAñodeing);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.txbLuz);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.txbInternet);
            this.groupBox2.Controls.Add(this.btnEliminar);
            this.groupBox2.Controls.Add(this.txbAgua);
            this.groupBox2.Controls.Add(this.btnEditar);
            this.groupBox2.Controls.Add(this.btnIngresar);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.txbGas);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(53, 15);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(6);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(6);
            this.groupBox2.Size = new System.Drawing.Size(614, 573);
            this.groupBox2.TabIndex = 1003;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Gastos Mensuales";
            // 
            // MesAñodeing
            // 
            this.MesAñodeing.CustomFormat = "MM/yyyy";
            this.MesAñodeing.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.MesAñodeing.Location = new System.Drawing.Point(197, 101);
            this.MesAñodeing.Name = "MesAñodeing";
            this.MesAñodeing.Size = new System.Drawing.Size(151, 41);
            this.MesAñodeing.TabIndex = 1;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(23, 101);
            this.label5.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(165, 36);
            this.label5.TabIndex = 1004;
            this.label5.Text = "Mes y Año:";
            // 
            // txbLuz
            // 
            this.txbLuz.Location = new System.Drawing.Point(158, 369);
            this.txbLuz.Margin = new System.Windows.Forms.Padding(6);
            this.txbLuz.Name = "txbLuz";
            this.txbLuz.Size = new System.Drawing.Size(298, 41);
            this.txbLuz.TabIndex = 5;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(23, 374);
            this.label4.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(72, 36);
            this.label4.TabIndex = 1002;
            this.label4.Text = "Luz:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(23, 305);
            this.label3.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(123, 36);
            this.label3.TabIndex = 1001;
            this.label3.Text = "Internet:";
            // 
            // txbInternet
            // 
            this.txbInternet.Location = new System.Drawing.Point(159, 300);
            this.txbInternet.Margin = new System.Windows.Forms.Padding(6);
            this.txbInternet.Name = "txbInternet";
            this.txbInternet.Size = new System.Drawing.Size(298, 41);
            this.txbInternet.TabIndex = 4;
            // 
            // btnEliminar
            // 
            this.btnEliminar.Location = new System.Drawing.Point(397, 454);
            this.btnEliminar.Margin = new System.Windows.Forms.Padding(6);
            this.btnEliminar.Name = "btnEliminar";
            this.btnEliminar.Size = new System.Drawing.Size(172, 58);
            this.btnEliminar.TabIndex = 8;
            this.btnEliminar.Text = "Eliminar";
            this.btnEliminar.UseVisualStyleBackColor = true;
            this.btnEliminar.Click += new System.EventHandler(this.btnEliminar_Click);
            // 
            // txbAgua
            // 
            this.txbAgua.Location = new System.Drawing.Point(159, 232);
            this.txbAgua.Margin = new System.Windows.Forms.Padding(6);
            this.txbAgua.Name = "txbAgua";
            this.txbAgua.Size = new System.Drawing.Size(298, 41);
            this.txbAgua.TabIndex = 3;
            // 
            // btnEditar
            // 
            this.btnEditar.Location = new System.Drawing.Point(213, 454);
            this.btnEditar.Margin = new System.Windows.Forms.Padding(6);
            this.btnEditar.Name = "btnEditar";
            this.btnEditar.Size = new System.Drawing.Size(172, 58);
            this.btnEditar.TabIndex = 7;
            this.btnEditar.Text = "Editar";
            this.btnEditar.UseVisualStyleBackColor = true;
            this.btnEditar.Click += new System.EventHandler(this.btnEditar_Click);
            // 
            // btnIngresar
            // 
            this.btnIngresar.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnIngresar.Location = new System.Drawing.Point(29, 454);
            this.btnIngresar.Margin = new System.Windows.Forms.Padding(6);
            this.btnIngresar.Name = "btnIngresar";
            this.btnIngresar.Size = new System.Drawing.Size(172, 58);
            this.btnIngresar.TabIndex = 6;
            this.btnIngresar.Text = "Ingresar";
            this.btnIngresar.UseVisualStyleBackColor = true;
            this.btnIngresar.Click += new System.EventHandler(this.btnIngresar_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(23, 178);
            this.label2.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(77, 36);
            this.label2.TabIndex = 999;
            this.label2.Text = "Gas:";
            // 
            // txbGas
            // 
            this.txbGas.Location = new System.Drawing.Point(159, 166);
            this.txbGas.Margin = new System.Windows.Forms.Padding(6);
            this.txbGas.Name = "txbGas";
            this.txbGas.Size = new System.Drawing.Size(298, 41);
            this.txbGas.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(23, 244);
            this.label1.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(94, 36);
            this.label1.TabIndex = 999;
            this.label1.Text = "Agua:";
            // 
            // btnCalcAnual
            // 
            this.btnCalcAnual.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalcAnual.Location = new System.Drawing.Point(679, 181);
            this.btnCalcAnual.Margin = new System.Windows.Forms.Padding(6);
            this.btnCalcAnual.Name = "btnCalcAnual";
            this.btnCalcAnual.Size = new System.Drawing.Size(195, 94);
            this.btnCalcAnual.TabIndex = 9;
            this.btnCalcAnual.Text = "Calcular Gasto Anual";
            this.btnCalcAnual.UseVisualStyleBackColor = true;
            this.btnCalcAnual.Visible = false;
            this.btnCalcAnual.Click += new System.EventHandler(this.btnCalcAnual_Click);
            // 
            // lblGastoAnual
            // 
            this.lblGastoAnual.AutoSize = true;
            this.lblGastoAnual.Font = new System.Drawing.Font("Microsoft YaHei", 22.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGastoAnual.Location = new System.Drawing.Point(686, 315);
            this.lblGastoAnual.Name = "lblGastoAnual";
            this.lblGastoAnual.Size = new System.Drawing.Size(0, 78);
            this.lblGastoAnual.TabIndex = 1005;
            this.lblGastoAnual.Visible = false;
            // 
            // btnLimpiar
            // 
            this.btnLimpiar.Location = new System.Drawing.Point(679, 132);
            this.btnLimpiar.Margin = new System.Windows.Forms.Padding(6);
            this.btnLimpiar.Name = "btnLimpiar";
            this.btnLimpiar.Size = new System.Drawing.Size(118, 37);
            this.btnLimpiar.TabIndex = 10;
            this.btnLimpiar.Text = "Limpiar";
            this.btnLimpiar.UseVisualStyleBackColor = true;
            this.btnLimpiar.Visible = false;
            this.btnLimpiar.Click += new System.EventHandler(this.btnLimpiar_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1148, 1151);
            this.Controls.Add(this.btnLimpiar);
            this.Controls.Add(this.lblGastoAnual);
            this.Controls.Add(this.btnCalcAnual);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.grillaGastos);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.grillaGastos)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.DataGridView grillaGastos;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txbLuz;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txbInternet;
        private System.Windows.Forms.Button btnEliminar;
        private System.Windows.Forms.TextBox txbAgua;
        private System.Windows.Forms.Button btnEditar;
        private System.Windows.Forms.Button btnIngresar;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txbGas;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridViewTextBoxColumn coMes;
        private System.Windows.Forms.DataGridViewTextBoxColumn coGas;
        private System.Windows.Forms.DataGridViewTextBoxColumn coAgua;
        private System.Windows.Forms.DataGridViewTextBoxColumn coInternet;
        private System.Windows.Forms.DataGridViewTextBoxColumn coLuz;
        private System.Windows.Forms.DataGridViewTextBoxColumn coGastoTotal;
        private System.Windows.Forms.DateTimePicker MesAñodeing;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnCalcAnual;
        private System.Windows.Forms.Label lblGastoAnual;
        private System.Windows.Forms.Button btnLimpiar;
    }
}

