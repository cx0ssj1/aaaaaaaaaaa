﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoTprog
{
    // Clase que representa los gastos mensuales de un mes específico.
    // Contiene propiedades para almacenar los gastos en diferentes categorías
    // y un método para calcular el total de gastos del mes.
    internal class GastoMensual
    {
        // Propiedad que almacena el mes y año del registro en formato "MM/yyyy".
        public string MesAño { get; set; }

        // Propiedad que almacena el gasto en gas para el mes especificado.
        public double Gas { get; set; }

        // Propiedad que almacena el gasto en agua para el mes especificado.
        public double Agua { get; set; }

        // Propiedad que almacena el gasto en internet para el mes especificado.
        public double Internet { get; set; }

        // Propiedad que almacena el gasto en luz para el mes especificado.
        public double Luz { get; set; }

        // Método que calcula el gasto total del mes.
        // Suma todos los gastos individuales (Gas, Agua, Internet, Luz)
        // y devuelve el total.
        public double CalcularGastoTotal()
        {
            return Gas + Agua + Internet + Luz;
        }
    }
}
